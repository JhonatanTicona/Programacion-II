/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.util.ArrayList;
import java.util.List;

public class Libro {

    private String titulo;
    private String isbn;
    private List<Pagina> paginas;

    public Libro(String titulo, String isbn, String[] contenidoPaginas) {
        this.titulo = titulo;
        this.isbn = isbn;
        this.paginas = new ArrayList<>();
        for (int i = 0; i < contenidoPaginas.length; i++) {
            paginas.add(new Pagina(i + 1, contenidoPaginas[i]));
        }
    }

    public String getTitulo() {
        return titulo;
    }

    public String getIsbn() {
        return isbn;
    }
    public void leer() {
        System.out.println("Paginas del Libro: " + titulo);
        for (Pagina p : paginas) {
            p.mostrarPagina();
        }
    }
    public class Pagina {

        private int nroPagina;
        private String contenido;

        public Pagina(int nroPagina, String contenido) {
            this.nroPagina = nroPagina;
            this.contenido = contenido;
        }

        public void mostrarPagina() {
            System.out.println("Pagina " + nroPagina + ": " + contenido);
        }

    }

}
