/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

public class SistemaBiblioteca {

    public static void main(String[] args) {

        Biblioteca biblioteca = new Biblioteca("Biblioteca UMSA");
        biblioteca.mostrarEstado();
        Autor autor1 = new Autor("William Faulkner", "Chile");
        Autor autor2 = new Autor("Oscar Wilde", "Argentina");

        Libro libro1 = new Libro("El ruido y la Furia", "ISBN-0001", new String[]{
            "Pagina 1: Inicio...", "Pagina 2: Desarrollo...", "Pagina 3: Fin."});

        Libro libro2 = new Libro("La importancia de ser formal", "ISBN-0002", new String[]{
            "Pagina 1", "Pagina 2", "Pagina 3."});
        System.out.println("");
        System.out.println("------ Agregacion de libros y autores a la biblioteca: -----");
        System.out.println("");
        biblioteca.agregarAutor(autor1);
        biblioteca.agregarAutor(autor2);
        biblioteca.agregarLibro(libro1);
        biblioteca.agregarLibro(libro2);
        biblioteca.mostrarEstado();

        System.out.println("");
        System.out.println("------ Asociacion Prestamo, Estudiante, Libro: -----");
        System.out.println("");
        Estudiante estudiante = new Estudiante("2023001", "Maria Perez");
        biblioteca.prestarLibro(estudiante, libro1);

        System.out.println("");
        System.out.println("------ COMPOSICION  Libro-Pagina (lectura de paginas del libro1): -----");
        System.out.println("");
        libro1.leer();
        
        System.out.println("");
        System.out.println("");
        biblioteca.mostrarEstado();

        System.out.println("\nCerrando biblioteca...");
        biblioteca.cerrarBiblioteca();

        System.out.println("\nLibro aun existe fuera de la biblioteca (AGREGACION):");
        libro2.leer();
    }
}
