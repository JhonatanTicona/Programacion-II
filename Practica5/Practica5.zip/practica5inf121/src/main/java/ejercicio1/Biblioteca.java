package ejercicio1;

import java.util.ArrayList;
public class Biblioteca {

    private String nombre;
    private ArrayList<Libro> libros;
    private ArrayList<Autor> autores;
    private ArrayList<Prestamo> prestamos;
    private Horario horario;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.libros = new ArrayList<Libro>();
        this.autores = new ArrayList<Autor>();
        this.prestamos = new ArrayList<Prestamo>();
        this.horario = new Horario("Lunes a Sabado","8:00","21:00");
    }

    public void agregarLibro(Libro libro) {
        if (!libros.contains(libro)) {
            libros.add(libro);
        }
    }

    public void agregarAutor(Autor autor) {
        if (!autores.contains(autor)) {
            autores.add(autor);
        }
    }

    public void prestarLibro(Estudiante estudiante, Libro libro) {
        if (!libros.contains(libro)) {
            System.out.println("El libro no esta en el Catalogo.");
            return;
        }
        Prestamo p = new Prestamo(estudiante, libro);
        prestamos.add(p);
        System.out.println("Prestamo registrado: " + estudiante.getNombre() + " -> " + libro.getTitulo());
    }

    public void mostrarEstado() {
        System.out.println("Biblioteca: " + nombre);
        System.out.println("Autores: " + autores.size());
        for (Autor a : autores) {
            a.mostrarInfo();
        }
        System.out.println("Libros: " + libros.size());
        for (Libro l : libros) {
            System.out.println(" - " + l.getTitulo());
        }
        System.out.println("Prestamos activos: " + prestamos.size());
        for (Prestamo p : prestamos) {
            p.mostrarInfo();
        }
        if (horario != null) {
            horario.mostrarHorario();
        }
    }

    public void cerrarBiblioteca() {
        prestamos.clear();
        System.out.println("Biblioteca cerrada, prestamos eliminados.");
    }
    public class Horario {
    private String diaApertura;
    private String hApertura;
    private String hCierre;
    
    public Horario(String diaApertura, String hApertura, String hCierre) {
        this.diaApertura = diaApertura;
        this.hApertura = hApertura;
        this.hCierre = hCierre;
       }
    public void mostrarHorario() {
         System.out.println("Horario: Dia apertura: " + diaApertura + ", De " + hApertura + " a " + hCierre);
    }
}

}
