package ejercicio1;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Empleado[] empleados = new Empleado[5];
        for (int i = 0; i < 3; i++) {
            System.out.println("Ingrese nombre del empleado tiempo completo: ");
            String nombre = sc.nextLine();
            System.out.println("Ingrese salario anual: ");
            double salarioAnual = sc.nextDouble();
            sc.nextLine();
            empleados[i] = new EmpleadoTiempoCompleto(nombre, salarioAnual);
        }
        for (int i = 3; i < 5; i++) {
            System.out.println("Ingrese nombre del empleado tiempo horario: ");
            String nombre = sc.nextLine();
            System.out.println("Ingrese horas trabajadas: ");
            double horas = sc.nextDouble();
            System.out.println("Ingrese tarifa por hora: ");
            double tarifa = sc.nextDouble();
            sc.nextLine(); 
            empleados[i] = new EmpleadoTiempoHorario(nombre, horas, tarifa);
        }
        System.out.println("\n	Lista de Empleados");
        for (Empleado emp : empleados) {
            System.out.println(emp.getNombre() + "  Salario Mensual: " + emp.CalcularSalarioMensual());
        }
    }
}