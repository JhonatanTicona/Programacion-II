package ejercicio2;
interface Coloreado {
    String comoColorear();
}
