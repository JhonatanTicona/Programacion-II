/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen;

import java.util.ArrayList;
public class MiTeleferico {
    private ArrayList<Linea> lineas;
    private double cantidadIngresos;
    
    public MiTeleferico(){
        lineas=new ArrayList<Linea>();
        Linea l1=new Linea("Amarillo");
        Linea l2=new Linea("Rojo");
        Linea l3=new Linea("Verde");
        lineas.add(l1);
        lineas.add(l2);
        lineas.add(l3);
        this.cantidadIngresos=0;
    }
    
    
    class Linea{
        private String color;
        private ArrayList<Persona> filaPersonas;
        private ArrayList<Cabina>cabinas;
        private int cantidadCabinas;

        public Linea(String color) {
            this.color = color;
            filaPersonas=new  ArrayList<Persona>() ;
            cabinas =new  ArrayList<Cabina>();
            cantidadCabinas=0;
            
            
        }
        
        
        
        
        class Cabina{
            private int nroCabina;
            private ArrayList<Persona> personasAbordo;
            
            public Cabina(int nrocabina){
                this.nroCabina=nroCabina;
                personasAbordo=new ArrayList<Persona>();
            }
            
        }
    }
    
}
