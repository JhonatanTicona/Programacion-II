/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen;

/**
 *
 * @author AREA_PROGRAMACION
 */
public class Persona {
    private String nombre;
    private int edad;
    private double pesoPersona;

    public Persona(String nombre, int edad, double pesoPersona) {
        this.nombre = nombre;
        this.edad = edad;
        this.pesoPersona = pesoPersona;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public double getPesoPersona() {
        return pesoPersona;
    }
    
    
}
