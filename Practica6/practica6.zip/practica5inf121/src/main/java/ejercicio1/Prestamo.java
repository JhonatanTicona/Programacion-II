
package ejercicio1;
import java.time.LocalDate;
public class Prestamo {
    private LocalDate fechaP;
    private LocalDate fechaDevolucion;
    private Estudiante estudiante;
    private Libro libro;

    public Prestamo(Estudiante estudiante, Libro libro) {
        this.fechaP = LocalDate.now();
        this.fechaDevolucion = fechaP.plusWeeks(2);
        this.estudiante = estudiante;
        this.libro = libro;
    }
    public void mostrarInfo() {
        System.out.println("Prestamo: '" + libro.getTitulo() + "' a " + estudiante.getNombre() +
        " | Fecha prestamo: " + fechaP + " | Devolucion: " + fechaDevolucion);
    }

    public LocalDate getFechaP() {
        return fechaP;
    }

    public void setFechaP(LocalDate fechaP) {
        this.fechaP = fechaP;
    }

    public LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(LocalDate fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }
    
    
}
