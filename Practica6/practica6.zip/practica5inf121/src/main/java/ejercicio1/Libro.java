package ejercicio1;
import java.util.ArrayList;
import java.util.List;
public class Libro {
    private String titulo;
    private String isbn;
    private List<Pagina> paginas;
    private Autor autor;

    public Libro(String titulo, String isbn, String[] contenidoPaginas,Autor autor) {
        this.titulo = titulo;
        this.isbn = isbn;
        this.autor=autor;
        this.paginas = new ArrayList<>();
        for (int i = 0; i < contenidoPaginas.length; i++) {
            paginas.add(new Pagina(i + 1, contenidoPaginas[i]));
        }
    }
    public String getTitulo() {
        return titulo;
    }

    public List<Pagina> getPaginas() {
        return paginas;
    }

    public void setPaginas(List<Pagina> paginas) {
        this.paginas = paginas;
    }

    public String getIsbn() {
        return isbn;
    }
    public void leer() {
        System.out.println("Paginas del Libro: " + titulo);
        for (Pagina p : paginas) {
            p.mostrarPagina();
        }
    }
    public class Pagina {
        private int nroPagina;
        private String contenido;

        public Pagina(int nroPagina, String contenido) {
            this.nroPagina = nroPagina;
            this.contenido = contenido;
        }
        public void mostrarPagina() {
            System.out.println("Pagina " + nroPagina + ": " + contenido);
        }

        public int getNroPagina() {
            return nroPagina;
        }

        public void setNroPagina(int nroPagina) {
            this.nroPagina = nroPagina;
        }

        public String getContenido() {
            return contenido;
        }

        public void setContenido(String contenido) {
            this.contenido = contenido;
        }
        
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Autor getAutor() {
        return autor;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }

}
