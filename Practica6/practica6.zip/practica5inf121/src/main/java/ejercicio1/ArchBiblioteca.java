/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

public class ArchBiblioteca {

    private static final String arch = "Biblioteca.json";

    private static final Gson gson = new GsonBuilder()
            .setPrettyPrinting()
            .registerTypeAdapter(LocalDate.class, new LocalDateAdapter())
            .create();

    public static void guardar(Biblioteca b) {
        try (FileWriter writer = new FileWriter(arch)) {
            gson.toJson(b, writer);
        } catch (IOException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }

    // Cargar TODA la biblioteca
    public static Biblioteca cargar() {
        try (FileReader reader = new FileReader(arch)) {
            return gson.fromJson(reader, Biblioteca.class);
        } catch (IOException e) {
            // Si no existe, devolvemos una nueva biblioteca
            return new Biblioteca("UMSA");
        }
    }
}