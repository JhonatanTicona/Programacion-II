package ejercicio1;
import java.util.ArrayList;
public class Biblioteca {
    private String nombre;
    private ArrayList<Libro> libros;
    private ArrayList<Autor> autores;
    private ArrayList<Prestamo> prestamos;
    private Horario horario;

    public Biblioteca() {
    }

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.libros = new ArrayList<Libro>();
        this.autores = new ArrayList<Autor>();
        this.prestamos = new ArrayList<Prestamo>();
        this.horario = new Horario("Lunes a Sabado","8:00","21:00");
    }
    public void agregarLibro(Libro libro) {
        if (!libros.contains(libro)) {
            libros.add(libro);
        }
    }
    public void agregarAutor(Autor autor) {
        if (!autores.contains(autor)) {
            autores.add(autor);
        }
    }
    public void prestarLibro(Estudiante estudiante, Libro libro) {
        if (!libros.contains(libro)) {
            System.out.println("El libro no esta en el Catalogo.");
            return;
        }
        Prestamo p = new Prestamo(estudiante, libro);
        prestamos.add(p);
        System.out.println("Prestamo registrado: " + estudiante.getNombre() + " -> " + libro.getTitulo());
    }
    public void mostrarEstado() {
        System.out.println("Biblioteca: " + nombre);
        System.out.println("Autores: " + autores.size());
        for (Autor a : autores) {
            a.mostrarInfo();
        }
        System.out.println("Libros: " + libros.size());
        for (Libro l : libros) {
            System.out.println(" - " + l.getTitulo());
        }
        System.out.println("Prestamos activos: " + prestamos.size());
        for (Prestamo p : prestamos) {
            p.mostrarInfo();
        }
        if (horario != null) {
            horario.mostrarHorario();
        }
    }
    public void cerrarBiblioteca() {
        prestamos.clear();
        System.out.println("Biblioteca cerrada, prestamos eliminados.");
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Libro> getLibros() {
        return libros;
    }

    public void setLibros(ArrayList<Libro> libros) {
        this.libros = libros;
    }

    public ArrayList<Autor> getAutores() {
        return autores;
    }

    public void setAutores(ArrayList<Autor> autores) {
        this.autores = autores;
    }

    public ArrayList<Prestamo> getPrestamos() {
        return prestamos;
    }

    public void setPrestamos(ArrayList<Prestamo> prestamos) {
        this.prestamos = prestamos;
    }

    public Horario getHorario() {
        return horario;
    }

    public void setHorario(Horario horario) {
        this.horario = horario;
    }
    
}
