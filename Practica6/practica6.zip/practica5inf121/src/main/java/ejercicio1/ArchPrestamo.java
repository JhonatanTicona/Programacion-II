/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.util.ArrayList;

public class ArchPrestamo {

    private static final String arch = "Prestamo.json";
    private static final Gson gson = new GsonBuilder()
            .setPrettyPrinting()
            .registerTypeAdapter(LocalDate.class, new LocalDateAdapter())
            .create();
    private static final Type TipoListaPrestamo =
            new TypeToken<ArrayList<Prestamo>>() {}.getType();

    public static void guardarLista(ArrayList<Prestamo> lista) {
        try (FileWriter writer = new FileWriter(arch)) {
            gson.toJson(lista, TipoListaPrestamo, writer);
        } catch (IOException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }

    public static ArrayList<Prestamo> cargarLista() {
        try (FileReader reader = new FileReader(arch)) {
            return gson.fromJson(reader, TipoListaPrestamo);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static void agregarPrestamo(Prestamo p) {
        ArrayList<Prestamo> lista = cargarLista();
        lista.add(p);
        guardarLista(lista);
    }

    public static boolean eliminarPrestamo(String nombreEstudiante, String isbnLibro) {
        ArrayList<Prestamo> lista = cargarLista();

        boolean eliminado = lista.removeIf(p ->
                p.getEstudiante().getNombre().equalsIgnoreCase(nombreEstudiante) &&
                p.getLibro().getIsbn().equalsIgnoreCase(isbnLibro)
        );

        if (eliminado) guardarLista(lista);
        return eliminado;
    }

    public static boolean actualizarPrestamo(Prestamo actualizado) {
        ArrayList<Prestamo> lista = cargarLista();

        for (int i = 0; i < lista.size(); i++) {
            Prestamo p = lista.get(i);

            if (p.getEstudiante().getNombre().equalsIgnoreCase(actualizado.getEstudiante().getNombre()) &&
                p.getLibro().getIsbn().equalsIgnoreCase(actualizado.getLibro().getIsbn())) {

                lista.set(i, actualizado);
                guardarLista(lista);
                return true;
            }
        }

        return false;
    }
}