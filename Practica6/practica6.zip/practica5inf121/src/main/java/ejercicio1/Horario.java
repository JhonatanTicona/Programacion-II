/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

public class Horario {
    private String diaApertura;
    private String hApertura;
    private String hCierre;
    
    public Horario(String diaApertura, String hApertura, String hCierre) {
        this.diaApertura = diaApertura;
        this.hApertura = hApertura;
        this.hCierre = hCierre;
       }
    public void mostrarHorario() {
         System.out.println("Horario: Dia apertura: " + diaApertura + ", De " + hApertura + " a " + hCierre);
    }

    public String getDiaApertura() {
        return diaApertura;
    }

    public void setDiaApertura(String diaApertura) {
        this.diaApertura = diaApertura;
    }

    public String gethApertura() {
        return hApertura;
    }

    public void sethApertura(String hApertura) {
        this.hApertura = hApertura;
    }

    public String gethCierre() {
        return hCierre;
    }

    public void sethCierre(String hCierre) {
        this.hCierre = hCierre;
    }
    
}   

