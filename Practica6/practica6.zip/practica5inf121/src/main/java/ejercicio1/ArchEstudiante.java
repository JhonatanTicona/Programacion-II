/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class ArchEstudiante {

    private static final String arch = "estudiantes.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private static final Type TipoListaEstudiantes =
            new TypeToken<ArrayList<Estudiante>>() {}.getType();

    public static void guardarLista(ArrayList<Estudiante> lista) {
        try (FileWriter writer = new FileWriter(arch)) {
            gson.toJson(lista, TipoListaEstudiantes, writer);
        } catch (IOException e) {
            System.out.println("Error: "+e);
        }
    }

    public static ArrayList<Estudiante> cargarLista() {
        try (FileReader reader = new FileReader(arch)) {
            return gson.fromJson(reader, TipoListaEstudiantes);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static void agregarEstudiante(Estudiante e) {
        ArrayList<Estudiante> lista = cargarLista();
        lista.add(e);
        guardarLista(lista);
    }
    public static boolean eliminarEstudiante(String codigo) {
        ArrayList<Estudiante> lista = cargarLista();
        boolean eliminado = lista.removeIf(est -> est.getCodigo().equals(codigo));

        if (eliminado) {
            guardarLista(lista);
        }
        return eliminado; 
    }

    public static boolean actualizarEstudiante(Estudiante actualizado) {
        ArrayList<Estudiante> lista = cargarLista();

        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCodigo().equals(actualizado.getCodigo())) {
                lista.set(i, actualizado); 
                guardarLista(lista);
                return true;
            }
        }

        return false; 
    }
}