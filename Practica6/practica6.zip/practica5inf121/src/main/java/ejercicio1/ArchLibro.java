/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class ArchLibro {

    private static final String arch = "Libro.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private static final Type TipoListaLibro =new TypeToken<ArrayList<Libro>>() {}.getType();

    public static void guardarLista(ArrayList<Libro> lista) {
        try (FileWriter writer = new FileWriter(arch)) {
            gson.toJson(lista, TipoListaLibro, writer);
        } catch (IOException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }
    public static ArrayList<Libro> cargarLista() {
        try (FileReader reader = new FileReader(arch)) {
            return gson.fromJson(reader, TipoListaLibro);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }
    public static void agregarLibro(Libro libro) {
        ArrayList<Libro> lista = cargarLista();
        lista.add(libro);
        guardarLista(lista);
    }
    public static boolean eliminarLibro(String isbn) {
        ArrayList<Libro> lista = cargarLista();
        boolean eliminado = lista.removeIf(lib -> lib.getIsbn().equals(isbn));

        if (eliminado) {
            guardarLista(lista);
        }
        return eliminado;
    }
    public static boolean actualizarLibro(Libro actualizado) {
        ArrayList<Libro> lista = cargarLista();

        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getIsbn().equals(actualizado.getIsbn())) {
                lista.set(i, actualizado);
                guardarLista(lista);
                return true;
            }
        }
        return false;
    }
}