/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.util.ArrayList;

public class Prueba {

    public static void main(String[] args) {

        ArchEstudiante.agregarEstudiante(new Estudiante("001", "Jhonatan"));
        ArchEstudiante.agregarEstudiante(new Estudiante("002", "Maria"));

        ArrayList<Estudiante> lista = ArchEstudiante.cargarLista();

        for (Estudiante e : lista) {
            e.mostrarInfo();
        }
        boolean ok = ArchEstudiante.eliminarEstudiante("001");
        System.out.println(ok ? "Eliminado" : "No existe");
        Estudiante nuevo = new Estudiante("003", "Juan Perez");
        boolean ok2 = ArchEstudiante.actualizarEstudiante(nuevo);
        System.out.println(ok2 ? "Actualizado" : "No existe");
        for (Estudiante e : lista) {
            e.mostrarInfo();
        }
    }
}
