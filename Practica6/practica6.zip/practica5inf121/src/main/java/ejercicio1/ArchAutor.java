/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class ArchAutor {

    private static final String arch = "Autor.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private static final Type TipoListaAutor =
            new TypeToken<ArrayList<Autor>>() {}.getType();

    public static void guardarLista(ArrayList<Autor> lista) {
        try (FileWriter writer = new FileWriter(arch)) {
            gson.toJson(lista, TipoListaAutor, writer);
        } catch (IOException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }

    public static ArrayList<Autor> cargarLista() {
        try (FileReader reader = new FileReader(arch)) {
            return gson.fromJson(reader, TipoListaAutor);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static void agregarAutor(Autor autor) {
        ArrayList<Autor> lista = cargarLista();
        lista.add(autor);
        guardarLista(lista);
    }
    public static boolean eliminarAutor(String nombre) {
        ArrayList<Autor> lista = cargarLista();
        boolean eliminado = lista.removeIf(a -> a.getNombre().equalsIgnoreCase(nombre));

        if (eliminado) {
            guardarLista(lista);
        }
        return eliminado;
    }

    public static boolean actualizarAutor(Autor actualizado) {
        ArrayList<Autor> lista = cargarLista();

        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().equalsIgnoreCase(actualizado.getNombre())) {
                lista.set(i, actualizado);
                guardarLista(lista);
                return true;
            }
        }
        return false;
    }
}