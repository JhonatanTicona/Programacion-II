/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

public class Estudiante {
    private String codigo;
    private String nombre;

    public Estudiante(String nombre, String codigo) {
        this.codigo = codigo;
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    public void mostrarInfo() {
        System.out.println("Estudiante: " + nombre + " (codigo: " + codigo + ")");
    }
}
