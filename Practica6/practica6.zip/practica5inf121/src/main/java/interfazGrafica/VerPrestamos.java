/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfazGrafica;

import ejercicio1.*;
import ejercicio1.Biblioteca;
import ejercicio1.Libro;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Huawei-JH
 */
public class VerPrestamos extends javax.swing.JFrame {

    private MenuBiblioteca menu;
    private Biblioteca biblioteca;

    public VerPrestamos() {
        initComponents();
    }

    public VerPrestamos(MenuBiblioteca menu, Biblioteca biblioteca) {
        initComponents();
        this.menu = menu;
        setTitle("Ver Prestamos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        this.biblioteca = biblioteca;
        cargarTablaLibros();
        cargarTablaPrestamos();
    }

    private void cargarTablaLibros() {
        // Definir columnas
        String[] columnas = {"TITULO", "AUTOR", "ISBN"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);

        for (Libro libro : biblioteca.getLibros()) {
            String titulo = libro.getTitulo();
            String autor = libro.getAutor().getNombre();
            String isbn = libro.getIsbn();
            Object[] fila = {titulo, autor, isbn};
            modelo.addRow(fila);
        }
        tablaLibros.setModel(modelo);
    }

private void cargarTablaPrestamos() {
    String[] columnas = {"NOMBRE", "CODIGO", "TITULO", "F PRESTAMO", "F DEVOLUCION"};
    DefaultTableModel modelo = new DefaultTableModel(columnas, 0);

    for (Prestamo p : biblioteca.getPrestamos()) {
        modelo.addRow(new Object[]{
            p.getEstudiante().getNombre(),
            p.getEstudiante().getCodigo(),
            p.getLibro().getTitulo(),
            p.getFechaP(),
            p.getFechaDevolucion()
        });
    }

    tablaPrestamos.setModel(modelo);
}

    private void cargarLibrosEnTabla() {
        DefaultTableModel modelo = (DefaultTableModel) tablaLibros.getModel();
        modelo.setRowCount(0);

        for (Libro libro : biblioteca.getLibros()) {
            modelo.addRow(new Object[]{
                libro.getTitulo(),
                libro.getAutor().getNombre(),
                libro.getIsbn()
            });
        }
    }

    private void cargarPrestamosEnTabla() {
        DefaultTableModel modelo = (DefaultTableModel) tablaPrestamos.getModel();
        modelo.setRowCount(0);

        for (Prestamo p : biblioteca.getPrestamos()) {
            modelo.addRow(new Object[]{
                p.getEstudiante().getNombre(),
                p.getEstudiante().getCodigo(),
                p.getLibro().getTitulo(),
                p.getFechaP(),
                p.getFechaDevolucion()
            });
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        botonVolver = new javax.swing.JButton();
        titulo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPrestamos = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaLibros = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        botonAgregarPrestamo = new javax.swing.JButton();
        botonEliminarPrestamo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        botonVolver.setBackground(new java.awt.Color(153, 153, 153));
        botonVolver.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonVolver.setForeground(new java.awt.Color(51, 0, 0));
        botonVolver.setText("VOLVER");
        botonVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverActionPerformed(evt);
            }
        });

        titulo.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(26, 35, 126));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("PRESTAMOS:");
        titulo.setVerifyInputWhenFocusTarget(false);

        tablaPrestamos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "NOMBRE ", "CODIGO", "TITULO", "F PRESTAMO", "F DEVOLUCION"
            }
        ));
        jScrollPane1.setViewportView(tablaPrestamos);

        tablaLibros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "TITULO", "AUTOR", "ISBN"
            }
        ));
        jScrollPane2.setViewportView(tablaLibros);

        jLabel1.setBackground(new java.awt.Color(51, 51, 255));
        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LIBROS PRESTADOS");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setBackground(new java.awt.Color(51, 51, 255));
        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ESTUDIANTE");
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setBackground(new java.awt.Color(51, 51, 255));
        jLabel3.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("LIBROS");
        jLabel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        botonAgregarPrestamo.setBackground(new java.awt.Color(204, 255, 255));
        botonAgregarPrestamo.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonAgregarPrestamo.setForeground(new java.awt.Color(26, 35, 126));
        botonAgregarPrestamo.setText("REALIZAR PRESTAMO");
        botonAgregarPrestamo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarPrestamoActionPerformed(evt);
            }
        });

        botonEliminarPrestamo.setBackground(new java.awt.Color(255, 204, 204));
        botonEliminarPrestamo.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonEliminarPrestamo.setForeground(new java.awt.Color(26, 35, 126));
        botonEliminarPrestamo.setText("FINALIZAR PRESTAMO");
        botonEliminarPrestamo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarPrestamoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 303, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(botonAgregarPrestamo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonEliminarPrestamo))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(botonVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 237, Short.MAX_VALUE)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(271, 271, 271)))
                .addGap(38, 38, 38))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(botonVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAgregarPrestamo, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonEliminarPrestamo, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverActionPerformed
        this.dispose(); // cerrar VerLibro
        menu.setVisible(true);
    }//GEN-LAST:event_botonVolverActionPerformed

    private void botonAgregarPrestamoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarPrestamoActionPerformed
        int filaSeleccionada = tablaLibros.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un libro para Agregar un Prestamo.");
            return;
        }

        // Obtener el libro actual
        Libro libro = biblioteca.getLibros().get(filaSeleccionada);

        JTextField nombreField = new JTextField();
        JTextField codigoField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Nombre del Estudiante:"));
        panel.add(nombreField);
        panel.add(new JLabel("Codigo del Estudiante"));
        panel.add(codigoField);

        int result = JOptionPane.showConfirmDialog(
                null, panel, "Agregar nuevo Prestamo",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (result == JOptionPane.OK_OPTION) {

            String nombre= nombreField.getText().trim();
            String codigo = codigoField.getText().trim();
            Estudiante e=new Estudiante(nombre,codigo);
            Prestamo nuevo=new Prestamo(e,libro);
            
            biblioteca.prestarLibro(e, libro);
            biblioteca.getLibros().remove(libro);
            ArchBiblioteca.guardar(biblioteca);
            ArchEstudiante.agregarEstudiante(e);
            ArchPrestamo.agregarPrestamo(nuevo);
            ArchLibro.eliminarLibro(libro.getIsbn());
            JOptionPane.showMessageDialog(null, "Prestamo agregado correctamente.");

            cargarLibrosEnTabla();
            cargarPrestamosEnTabla();
        }
    }//GEN-LAST:event_botonAgregarPrestamoActionPerformed

    private void botonEliminarPrestamoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarPrestamoActionPerformed
            int filaSeleccionada = tablaPrestamos.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un Prestamo para Finalizar.");
        return;
    }
    Prestamo prestamoAEliminar = biblioteca.getPrestamos().get(filaSeleccionada);

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "¿Esta seguro de Finalizar el prestamo del Estudiante:\n" + prestamoAEliminar.getEstudiante().getNombre()+ "?",
            "Confirmar Finalizacion",
            JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }
    Libro libro= prestamoAEliminar.getLibro();
    biblioteca.getLibros().add(libro);
    biblioteca.getPrestamos().remove(prestamoAEliminar);

    ArchBiblioteca.guardar(biblioteca);
    ArchLibro.agregarLibro(libro);
    ArchEstudiante.eliminarEstudiante(prestamoAEliminar.getEstudiante().getCodigo());
    ArchPrestamo.eliminarPrestamo(prestamoAEliminar.getEstudiante().getNombre(),prestamoAEliminar.getLibro().getIsbn());
    
    JOptionPane.showMessageDialog(this, "Prestamo Finalizado con exito.");

    cargarLibrosEnTabla();
    cargarPrestamosEnTabla();
    }//GEN-LAST:event_botonEliminarPrestamoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VerPrestamos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VerPrestamos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VerPrestamos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VerPrestamos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VerPrestamos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregarPrestamo;
    private javax.swing.JButton botonEliminarPrestamo;
    private javax.swing.JButton botonVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tablaLibros;
    private javax.swing.JTable tablaPrestamos;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
