/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfazGrafica;

import javax.swing.JFrame;
import javax.swing.*;
import ejercicio1.*;
import ejercicio1.Libro.Pagina;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class VerLibro extends javax.swing.JFrame {
    private MenuBiblioteca menu;
    private Biblioteca biblioteca;
    
    public VerLibro() {
        
    }
    public VerLibro(MenuBiblioteca menu,Biblioteca biblioteca) {
        initComponents();
        this.menu = menu;
        setTitle("Ver Libros");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        this.biblioteca = biblioteca;
        cargarTabla();
    }
private void cargarTabla() {
    // Definir columnas
    String[] columnas = {"TITULO", "AUTOR", "ISBN", "Nro Paginas"};

    // Crear modelo de tabla vacío
    DefaultTableModel modelo = new DefaultTableModel(columnas, 0);

    // Llenar modelo con los libros
    for (Libro libro : biblioteca.getLibros()) {
        String titulo = libro.getTitulo();
        String autor = libro.getAutor().getNombre(); 
        String isbn = libro.getIsbn();
        List<Pagina> paginas = libro.getPaginas();
        int nroPaginas = paginas.size();
        Object[] fila = {titulo, autor, isbn, nroPaginas};
        modelo.addRow(fila);
    }

    // Asignar modelo a la tabla
    tablaLibros.setModel(modelo);
}
private void cargarLibrosEnTabla() {
    DefaultTableModel modelo = (DefaultTableModel) tablaLibros.getModel();
    modelo.setRowCount(0);

    for (Libro libro : biblioteca.getLibros()) {
        modelo.addRow(new Object[]{
            libro.getTitulo(),
            libro.getAutor().getNombre(),
            libro.getIsbn(),
            libro.getPaginas().size()
        });
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        botonVolver = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaLibros = new javax.swing.JTable();
        botonAgregarLibro = new javax.swing.JButton();
        BotonEditarLibro = new javax.swing.JButton();
        botonEliminarLibro = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        titulo.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(26, 35, 126));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("LIBROS:");
        titulo.setVerifyInputWhenFocusTarget(false);

        botonVolver.setBackground(new java.awt.Color(153, 153, 153));
        botonVolver.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonVolver.setForeground(new java.awt.Color(51, 0, 0));
        botonVolver.setText("VOLVER");
        botonVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverActionPerformed(evt);
            }
        });

        tablaLibros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "TITULO", "AUTOR", "ISBN", "NRO PAGINAS"
            }
        ));
        jScrollPane1.setViewportView(tablaLibros);

        botonAgregarLibro.setBackground(new java.awt.Color(204, 255, 255));
        botonAgregarLibro.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonAgregarLibro.setForeground(new java.awt.Color(26, 35, 126));
        botonAgregarLibro.setText("Agregar Libro");
        botonAgregarLibro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarLibroActionPerformed(evt);
            }
        });

        BotonEditarLibro.setBackground(new java.awt.Color(255, 255, 204));
        BotonEditarLibro.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        BotonEditarLibro.setForeground(new java.awt.Color(26, 35, 126));
        BotonEditarLibro.setText("Editar Libro");
        BotonEditarLibro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonEditarLibroActionPerformed(evt);
            }
        });

        botonEliminarLibro.setBackground(new java.awt.Color(255, 204, 204));
        botonEliminarLibro.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonEliminarLibro.setForeground(new java.awt.Color(26, 35, 126));
        botonEliminarLibro.setText("EliminarLibro");
        botonEliminarLibro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarLibroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonAgregarLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonEliminarLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonEditarLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(botonVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(botonVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(botonAgregarLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(BotonEditarLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(botonEliminarLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverActionPerformed
        this.dispose(); // cerrar VerLibro
         menu.setVisible(true);
    }//GEN-LAST:event_botonVolverActionPerformed

    private void BotonEditarLibroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonEditarLibroActionPerformed
        int filaSeleccionada = tablaLibros.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un libro para editar.");
        return;
    }

    // Obtener el libro actual
    Libro libro = biblioteca.getLibros().get(filaSeleccionada);

    // Pedir nuevos valores
    String nuevoTitulo = JOptionPane.showInputDialog("Nuevo título:", libro.getTitulo());
    if (nuevoTitulo == null || nuevoTitulo.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "El título no puede estar vacío.");
        return;
    }

    String nuevoAutorNombre = JOptionPane.showInputDialog("Nuevo nombre del autor:", libro.getAutor().getNombre());
    if (nuevoAutorNombre == null || nuevoAutorNombre.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "El nombre del autor no puede estar vacío.");
        return;
    }

    String nuevoIsbn = JOptionPane.showInputDialog("Nuevo ISBN:", libro.getIsbn());
    if (nuevoIsbn == null || nuevoIsbn.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "El ISBN no puede estar vacío.");
        return;
    }

    // VALIDAR ISBN REPETIDO (exceptuando este mismo libro)
    for (Libro l : biblioteca.getLibros()) {
        if (!l.equals(libro) && l.getIsbn().equalsIgnoreCase(nuevoIsbn)) {
            JOptionPane.showMessageDialog(this, "Ya existe otro libro con ese ISBN.");
            return;
        }
    }

    // VALIDAR AUTOR EXISTENTE EN LA BIBLIOTECA
    Autor autorEncontrado = null;
    for (Autor a : biblioteca.getAutores()) {
        if (a.getNombre().equalsIgnoreCase(nuevoAutorNombre)) {
            autorEncontrado = a;
            break;
        }
    }

    if (autorEncontrado == null) {
        JOptionPane.showMessageDialog(this, "El autor no existe en la biblioteca.");
        return;
    }

    // Actualizar datos del libro
    libro.setTitulo(nuevoTitulo);
    libro.setAutor(autorEncontrado);
    libro.setIsbn(nuevoIsbn);

    // Guardar cambios
    ArchBiblioteca.guardar(biblioteca);
    ArchLibro.actualizarLibro(libro);
    JOptionPane.showMessageDialog(this, "Libro actualizado con éxito.");

    // Refrescar tabla (usa tu propio método)
     cargarLibrosEnTabla();
    }//GEN-LAST:event_BotonEditarLibroActionPerformed

    private void botonAgregarLibroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarLibroActionPerformed
JTextField tituloField = new JTextField();
    JTextField autorField = new JTextField();
    JTextField isbnField = new JTextField();

    JPanel panel = new JPanel(new GridLayout(4, 2));
    panel.add(new JLabel("Título:"));
    panel.add(tituloField);
    panel.add(new JLabel("Autor (nombre):"));
    panel.add(autorField);
    panel.add(new JLabel("ISBN:"));
    panel.add(isbnField);

    int result = JOptionPane.showConfirmDialog(
            null, panel, "Agregar nuevo libro",
            JOptionPane.OK_CANCEL_OPTION
    );

    if (result == JOptionPane.OK_OPTION) {

        String titulo = tituloField.getText().trim();
        String nombreAutor = autorField.getText().trim();
        String isbn = isbnField.getText().trim();
        Autor autorEncontrado = null;
        if (titulo.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "El título no puede estar vacío.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (isbn.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "El ISBN no puede estar vacío.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        for (Libro l : biblioteca.getLibros()) {
            if (l.getIsbn().equalsIgnoreCase(isbn)) {
                JOptionPane.showMessageDialog(null,
                        "El ISBN ya existe en la biblioteca.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        for (Autor a : biblioteca.getAutores()) {
            if (a.getNombre().equalsIgnoreCase(nombreAutor)) {
                autorEncontrado = a;
                break;
            }
        }

        if (autorEncontrado == null) {
            JOptionPane.showMessageDialog(null,
                    "El autor NO existe en la biblioteca.\nPrimero debe registrarlo.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        }

        Libro nuevo = new Libro(titulo, isbn, new String[]{
            "Pagina 1: Inicio...", "Pagina 2: Desarrollo...", "Pagina 3: Fin."},autorEncontrado);

        biblioteca.agregarLibro(nuevo);
        ArchBiblioteca.guardar(biblioteca);
        ArchLibro.agregarLibro(nuevo);
        JOptionPane.showMessageDialog(null, "Libro agregado correctamente.");

        cargarLibrosEnTabla();
    }
    }//GEN-LAST:event_botonAgregarLibroActionPerformed

    private void botonEliminarLibroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarLibroActionPerformed
    int filaSeleccionada = tablaLibros.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un libro para eliminar.");
        return;
    }
    Libro libroAEliminar = biblioteca.getLibros().get(filaSeleccionada);

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "¿Esta seguro de eliminar el libro:\n" + libroAEliminar.getTitulo() + "?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
    );
    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }
    biblioteca.getLibros().remove(libroAEliminar);
    ArchBiblioteca.guardar(biblioteca);
    ArchLibro.eliminarLibro(libroAEliminar.getIsbn());
    JOptionPane.showMessageDialog(this, "Libro eliminado con exito.");
    cargarLibrosEnTabla();
    }//GEN-LAST:event_botonEliminarLibroActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VerLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VerLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VerLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VerLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VerLibro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonEditarLibro;
    private javax.swing.JButton botonAgregarLibro;
    private javax.swing.JButton botonEliminarLibro;
    private javax.swing.JButton botonVolver;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaLibros;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
