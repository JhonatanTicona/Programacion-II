/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfazGrafica;

import javax.swing.*;
import ejercicio1.*;
import java.awt.CardLayout;
import java.awt.GridLayout;

public class MenuBiblioteca extends javax.swing.JFrame {

    private CardLayout cardLayout;

    private Biblioteca biblioteca;

    public MenuBiblioteca() {
        initComponents();
        cardLayout = new CardLayout();
        biblioteca = ArchBiblioteca.cargar();

        setTitle("Sistema de Biblioteca");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        Horario horario = biblioteca.getHorario();
        String textoHorario = "Horario de la Biblioteca:\n"
                + "Días de apertura: " + horario.getDiaApertura() + "\n"
                + "Horario: " + horario.gethApertura() + " a " + horario.gethCierre();
        txtHorario.setText(textoHorario);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelMenu = new javax.swing.JPanel();
        botonVerLibros = new javax.swing.JButton();
        titulo = new javax.swing.JLabel();
        botonVerAutores = new javax.swing.JButton();
        botonVerPrestamos = new javax.swing.JButton();
        titulo1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtHorario = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        botonCambiarHorario = new javax.swing.JButton();
        botonCerrarBiblioteca = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        PanelMenu.setBackground(new java.awt.Color(0, 153, 153));
        PanelMenu.setToolTipText("");

        botonVerLibros.setBackground(new java.awt.Color(204, 255, 255));
        botonVerLibros.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonVerLibros.setForeground(new java.awt.Color(26, 35, 126));
        botonVerLibros.setText("VER LIBROS");
        botonVerLibros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVerLibrosActionPerformed(evt);
            }
        });

        titulo.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(26, 35, 126));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("BIENVENIDO A LA BIBLIOTECA ");
        titulo.setVerifyInputWhenFocusTarget(false);

        botonVerAutores.setBackground(new java.awt.Color(204, 255, 255));
        botonVerAutores.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonVerAutores.setForeground(new java.awt.Color(26, 35, 126));
        botonVerAutores.setText("VER AUTORES");
        botonVerAutores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVerAutoresActionPerformed(evt);
            }
        });

        botonVerPrestamos.setBackground(new java.awt.Color(204, 255, 255));
        botonVerPrestamos.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonVerPrestamos.setForeground(new java.awt.Color(26, 35, 126));
        botonVerPrestamos.setText("VER PRESTAMOS");
        botonVerPrestamos.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        botonVerPrestamos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVerPrestamosActionPerformed(evt);
            }
        });

        titulo1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        titulo1.setForeground(new java.awt.Color(26, 35, 126));
        titulo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo1.setText("UNIVERSITARIA UMSA");
        titulo1.setVerifyInputWhenFocusTarget(false);

        txtHorario.setEditable(false);
        txtHorario.setBackground(new java.awt.Color(245, 245, 245));
        txtHorario.setColumns(20);
        txtHorario.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        txtHorario.setForeground(new java.awt.Color(26, 35, 126));
        txtHorario.setRows(5);
        txtHorario.setWrapStyleWord(true);
        jScrollPane1.setViewportView(txtHorario);

        jLabel1.setBackground(new java.awt.Color(51, 51, 255));
        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("HORARIO");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        botonCambiarHorario.setBackground(new java.awt.Color(204, 255, 204));
        botonCambiarHorario.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        botonCambiarHorario.setForeground(new java.awt.Color(26, 35, 126));
        botonCambiarHorario.setText("CAMBIAR HORARIO");
        botonCambiarHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCambiarHorarioActionPerformed(evt);
            }
        });

        botonCerrarBiblioteca.setBackground(new java.awt.Color(255, 153, 153));
        botonCerrarBiblioteca.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonCerrarBiblioteca.setForeground(new java.awt.Color(255, 51, 51));
        botonCerrarBiblioteca.setText("CERRAR BIBLIOTECA");
        botonCerrarBiblioteca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCerrarBibliotecaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelMenuLayout = new javax.swing.GroupLayout(PanelMenu);
        PanelMenu.setLayout(PanelMenuLayout);
        PanelMenuLayout.setHorizontalGroup(
            PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuLayout.createSequentialGroup()
                .addGroup(PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMenuLayout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(titulo1, javax.swing.GroupLayout.PREFERRED_SIZE, 556, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelMenuLayout.createSequentialGroup()
                        .addGap(141, 141, 141)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 556, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelMenuLayout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addGroup(PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 665, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PanelMenuLayout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 495, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(botonCambiarHorario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(PanelMenuLayout.createSequentialGroup()
                                .addGroup(PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(botonVerLibros, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(botonCerrarBiblioteca, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(50, 50, 50)
                                .addComponent(botonVerAutores, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(botonVerPrestamos, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(99, Short.MAX_VALUE))
        );
        PanelMenuLayout.setVerticalGroup(
            PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(titulo1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonCambiarHorario))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonVerAutores, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonVerLibros, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonVerPrestamos, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(94, 94, 94)
                .addComponent(botonCerrarBiblioteca, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );

        getContentPane().add(PanelMenu, java.awt.BorderLayout.LINE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonVerAutoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVerAutoresActionPerformed
        this.setVisible(false); 
        VerAutores vf = new VerAutores(this,biblioteca); 
        vf.setVisible(true);
    }//GEN-LAST:event_botonVerAutoresActionPerformed

    private void botonCambiarHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCambiarHorarioActionPerformed
        JTextField diasField = new JTextField();
        JTextField aperturaField = new JTextField();
        JTextField cierreField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("Días de apertura:"));
        panel.add(diasField);
        panel.add(new JLabel("Hora de apertura:"));
        panel.add(aperturaField);
        panel.add(new JLabel("Hora de cierre:"));
        panel.add(cierreField);

        int result = JOptionPane.showConfirmDialog(null, panel,
                "Ingrese nuevo horario", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            Horario nuevoHorario = new Horario(diasField.getText(), aperturaField.getText(), cierreField.getText());
            biblioteca.setHorario(nuevoHorario);
            txtHorario.setText(
                    "Horario de la Biblioteca:\n"
                    + "Días de apertura: " + nuevoHorario.getDiaApertura() + "\n"
                    + "Horario: " + nuevoHorario.gethApertura() + " a " + nuevoHorario.gethCierre()
            );
            ArchBiblioteca.guardar(biblioteca);
        }
    }//GEN-LAST:event_botonCambiarHorarioActionPerformed

    private void botonVerLibrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVerLibrosActionPerformed
        this.setVisible(false); 
        VerLibro vf = new VerLibro(this,biblioteca); 
        vf.setVisible(true);
    }//GEN-LAST:event_botonVerLibrosActionPerformed

    private void botonVerPrestamosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVerPrestamosActionPerformed
        this.setVisible(false); 
        VerPrestamos vf = new VerPrestamos(this,biblioteca); 
        vf.setVisible(true);
    }//GEN-LAST:event_botonVerPrestamosActionPerformed

    private void botonCerrarBibliotecaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCerrarBibliotecaActionPerformed
            int opcion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro de cerrar la biblioteca?\n" +
            "Se eliminaran todos los prestamos y los libros seran devueltos.",
            "Confirmar cierre",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (opcion == JOptionPane.YES_OPTION) {

        java.util.ArrayList<Prestamo> prestamos = ArchPrestamo.cargarLista();
        for (Prestamo p : prestamos) {
            Libro libroPrestado = p.getLibro();
            if (libroPrestado != null) {
                biblioteca.getLibros().add(libroPrestado);
                ArchLibro.agregarLibro(libroPrestado);
            }
        }
        prestamos.clear();
        biblioteca.getPrestamos().clear();
        ArchBiblioteca.guardar(biblioteca);
        ArchPrestamo.guardarLista(prestamos);

        JOptionPane.showMessageDialog(
                this,
                "La biblioteca ha sido cerrada correctamente.\n" +
                "Todos los prestamos fueron eliminados y los libros devueltos.",
                "Cierre exitoso",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
    }//GEN-LAST:event_botonCerrarBibliotecaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuBiblioteca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuBiblioteca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuBiblioteca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuBiblioteca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuBiblioteca().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelMenu;
    private javax.swing.JButton botonCambiarHorario;
    private javax.swing.JButton botonCerrarBiblioteca;
    private javax.swing.JButton botonVerAutores;
    private javax.swing.JButton botonVerLibros;
    private javax.swing.JButton botonVerPrestamos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel titulo;
    private javax.swing.JLabel titulo1;
    private javax.swing.JTextArea txtHorario;
    // End of variables declaration//GEN-END:variables
}
