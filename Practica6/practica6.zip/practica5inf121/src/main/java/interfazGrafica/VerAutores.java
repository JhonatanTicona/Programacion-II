/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfazGrafica;

import ejercicio1.Biblioteca;
import ejercicio1.Libro;
import ejercicio1.*;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class VerAutores extends javax.swing.JFrame {
    private MenuBiblioteca menu;
    private Biblioteca biblioteca;
    
    public VerAutores() {
        initComponents();
    }
    public VerAutores(MenuBiblioteca menu,Biblioteca biblioteca) {
        initComponents();
        this.menu = menu;
        setTitle("Ver Autores");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        this.biblioteca = biblioteca;
        cargarTabla();
    }
 private void cargarTabla() {
    // Definir columnas
    String[] columnas = {"NOMBRE", "NACIONALIDAD"};

    // Crear modelo de tabla vacío
    DefaultTableModel modelo = new DefaultTableModel(columnas, 0);

    // Llenar modelo con los libros
    for (Autor autor : biblioteca.getAutores()) {
        String nombre = autor.getNombre();
        String nacionalidad = autor.getNacionalidad(); 
        Object[] fila = {nombre,nacionalidad};
        modelo.addRow(fila);
    }
     tablaAutores.setModel(modelo);
 }
 private void cargarAutoresEnTabla() {
    DefaultTableModel modelo = (DefaultTableModel) tablaAutores.getModel();
    modelo.setRowCount(0);

    for (Autor autor : biblioteca.getAutores()) {
        modelo.addRow(new Object[]{
            autor.getNombre(),
            autor.getNacionalidad()
        });
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        botonVolver = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaAutores = new javax.swing.JTable();
        titulo = new javax.swing.JLabel();
        botonAgregarAutor = new javax.swing.JButton();
        botonEditarAutor = new javax.swing.JButton();
        botonEliminarAutor = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        botonVolver.setBackground(new java.awt.Color(153, 153, 153));
        botonVolver.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonVolver.setForeground(new java.awt.Color(51, 0, 0));
        botonVolver.setText("VOLVER");
        botonVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverActionPerformed(evt);
            }
        });

        tablaAutores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "NOMBRE", "NACIONALIDAD"
            }
        ));
        jScrollPane1.setViewportView(tablaAutores);

        titulo.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        titulo.setForeground(new java.awt.Color(26, 35, 126));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("AUTORES:");
        titulo.setVerifyInputWhenFocusTarget(false);

        botonAgregarAutor.setBackground(new java.awt.Color(204, 255, 255));
        botonAgregarAutor.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonAgregarAutor.setForeground(new java.awt.Color(26, 35, 126));
        botonAgregarAutor.setText("Agregar Autor");
        botonAgregarAutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarAutorActionPerformed(evt);
            }
        });

        botonEditarAutor.setBackground(new java.awt.Color(255, 255, 204));
        botonEditarAutor.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonEditarAutor.setForeground(new java.awt.Color(26, 35, 126));
        botonEditarAutor.setText("Editar Autor");
        botonEditarAutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEditarAutorActionPerformed(evt);
            }
        });

        botonEliminarAutor.setBackground(new java.awt.Color(255, 204, 204));
        botonEliminarAutor.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        botonEliminarAutor.setForeground(new java.awt.Color(26, 35, 126));
        botonEliminarAutor.setText("Eliminar Autor");
        botonEliminarAutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarAutorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(botonAgregarAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonEliminarAutor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonEditarAutor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGap(17, 17, 17))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(botonVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(185, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(botonVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(botonAgregarAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(45, 45, 45)
                        .addComponent(botonEditarAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(botonEliminarAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverActionPerformed
        this.dispose(); // cerrar VerLibro
        menu.setVisible(true);
    }//GEN-LAST:event_botonVolverActionPerformed

    private void botonAgregarAutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarAutorActionPerformed
    JTextField nombreField = new JTextField();
    JTextField nacionalidadField = new JTextField();
    

    JPanel panel = new JPanel(new GridLayout(4, 2));
    panel.add(new JLabel("Nombre:"));
    panel.add(nombreField);
    panel.add(new JLabel("Nacionalidad:"));
    panel.add(nacionalidadField);
    int result = JOptionPane.showConfirmDialog(
            null, panel, "Agregar nuevo Autor",
            JOptionPane.OK_CANCEL_OPTION
    );

    if (result == JOptionPane.OK_OPTION) {

        String nombre = nombreField.getText().trim();
        String nacionalidad = nacionalidadField.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "El nombre no puede estar vacio.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (nacionalidad.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "La Nacionalidad no puede estar vacio.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Autor nuevo = new Autor(nombre,nacionalidad);

        biblioteca.agregarAutor(nuevo);
        ArchAutor.agregarAutor(nuevo);
        ArchBiblioteca.guardar(biblioteca);

        JOptionPane.showMessageDialog(null, "Autor agregado correctamente.");

        cargarAutoresEnTabla();
    }
    }//GEN-LAST:event_botonAgregarAutorActionPerformed

    private void botonEditarAutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEditarAutorActionPerformed
       int filaSeleccionada = tablaAutores.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un Autor para editar.");
        return;
    }

  
    Autor autor = biblioteca.getAutores().get(filaSeleccionada);

    // Pedir nuevos valores
    String nuevoNombre = JOptionPane.showInputDialog("Nuevo Nombre:", autor.getNombre());
    if (nuevoNombre == null || nuevoNombre.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "El Nombre no puede estar vacío.");
        return;
    }

    String nuevaNacionalidad = JOptionPane.showInputDialog("Nueva Nacionalidad del autor:", autor.getNacionalidad());
    if (nuevaNacionalidad == null || nuevaNacionalidad.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "La nueva Nacionalidad del autor no puede estar vacío.");
        return;
    }
    boolean autorEncontrado = false;
    for (Autor a : biblioteca.getAutores()) {
        if (a.getNombre().equalsIgnoreCase(nuevoNombre)) {
            autorEncontrado = true;
            break;
        }
    }
    if (autorEncontrado == true) {
        JOptionPane.showMessageDialog(this, "El autor ya existe en la biblioteca.");
        return;
    }
    autor.setNombre(nuevoNombre);
    autor.setNacionalidad(nuevaNacionalidad);
    ArchBiblioteca.guardar(biblioteca);
    ArchAutor.actualizarAutor(autor);

    JOptionPane.showMessageDialog(this, "Autor actualizado con éxito.");

    // Refrescar tabla (usa tu propio método)
     cargarAutoresEnTabla();
    }//GEN-LAST:event_botonEditarAutorActionPerformed

    private void botonEliminarAutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarAutorActionPerformed
    int filaSeleccionada = tablaAutores.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un Autor para Eliminar.");
        return;
    }
    Autor autorAEliminar = biblioteca.getAutores().get(filaSeleccionada);

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "¿Esta seguro de eliminar el Autor:\n" + autorAEliminar.getNombre() + "?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    // Eliminar libro
    biblioteca.getAutores().remove(autorAEliminar);

    // Guardar
    ArchBiblioteca.guardar(biblioteca);
    ArchAutor.eliminarAutor(autorAEliminar.getNombre());
    JOptionPane.showMessageDialog(this, "Autor eliminado con exito.");

    // Refrescar tabla
    cargarAutoresEnTabla();
    }//GEN-LAST:event_botonEliminarAutorActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VerAutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VerAutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VerAutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VerAutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VerAutores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregarAutor;
    private javax.swing.JButton botonEditarAutor;
    private javax.swing.JButton botonEliminarAutor;
    private javax.swing.JButton botonVolver;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaAutores;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
