package ejercicio1;
public class Tests {

    public static void main(String[] args) {
        AlgebraVectorial a = new AlgebraVectorial(2, 4, 5);
        AlgebraVectorial b = new AlgebraVectorial(-3, 7, 4);

        System.out.println("a = " + a);
        System.out.println("b = " + b);

        System.out.println("a) |a+b| = |a-b|?: " + a.perpendicular(b,b.getY(),b.getZ()));
        System.out.println("b) |a-b| = |b-a|?: " + a.perpendicular(b.getX(),b.getY(),b.getZ()));
        System.out.println("c) a*b = 0 ?: " + a.perpendicular(b));
        System.out.println("d) |a+b|^2 = |a|^2 + |b|^2?: " + a.perpendicular(b,b.getY()));
        System.out.println("e) a = r*b ?: " + a.paralela(b));
        System.out.println("f) a x b = 0 ?: " + a.paralela1(b));
        System.out.println("g) Proyeccion de a sobre b: " + a.Proyeccion_de_a_sobre_b(b));
        System.out.println("h) Componente de a en direccion de b: " + a.Componente_de_a_en_b(b));
    
    }
    
}
