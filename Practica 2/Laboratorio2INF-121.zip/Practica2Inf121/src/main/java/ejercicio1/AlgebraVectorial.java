package ejercicio1;
public class AlgebraVectorial {
    private double x;
    private double y;
    private double z;

    public AlgebraVectorial() {
        x=0;
        y=0;
        z=0;
    }
    public AlgebraVectorial(double x, double y) {
        this.x=x;
        this.y=y;
        z=0;
    }
    public AlgebraVectorial(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public boolean perpendicular(AlgebraVectorial b,double y2,double z2) {
        AlgebraVectorial suma = new AlgebraVectorial(this.x + b.x, this.y +y2, this.z + z2);
        AlgebraVectorial resta = new AlgebraVectorial(this.x - b.x, this.y - y2, this.z - z2);
        return Math.abs(suma.norma() - resta.norma()) < 1e-9;
    }

    public boolean perpendicular(double x2,double y2,double z2) {
        AlgebraVectorial resta1 = new AlgebraVectorial(this.x - x2, this.y - y2, this.z - z2);
        AlgebraVectorial resta2 = new AlgebraVectorial(x2 - this.x, y2 - this.y, z2- this.z);
        return Math.abs(resta1.norma() - resta2.norma()) < 1e-9;
    }

    public boolean perpendicular(AlgebraVectorial b) {
        return Math.abs(this.productoPunto(b)) < 1e-9;
    }

    public boolean perpendicular(AlgebraVectorial b,double y2) {
        AlgebraVectorial suma = new AlgebraVectorial(this.x + b.x, this.y + y2, this.z + b.z);
        double izquierda = Math.pow(suma.norma(), 2);
        double derecha = Math.pow(this.norma(), 2) + Math.pow(b.norma(), 2);
        return Math.abs(izquierda - derecha) < 1e-9;
    }

    public boolean paralela(AlgebraVectorial b) {
        AlgebraVectorial cruz = this.productoCruz(b);
        return Math.abs(cruz.x) < 1e-9 && Math.abs(cruz.y) < 1e-9 && Math.abs(cruz.z) < 1e-9;
    }

    public boolean paralela1(AlgebraVectorial b) {
        AlgebraVectorial cruz = this.productoCruz(b);
        return Math.abs(cruz.x) < 1e-9 && Math.abs(cruz.y) < 1e-9 && Math.abs(cruz.z) < 1e-9;
    }

    public AlgebraVectorial Proyeccion_de_a_sobre_b(AlgebraVectorial b) {
        double escalar = this.productoPunto(b) / Math.pow(b.norma(), 2);
        return new AlgebraVectorial(escalar * b.x, escalar * b.y, escalar * b.z);
    }

    public double Componente_de_a_en_b(AlgebraVectorial b) {
        return this.productoPunto(b) / b.norma();
    }

    @Override
    public String toString() {
        return String.format("x: %.2f y: %.2f z: %.2f",x,y,z);
    }
    
    public double productoPunto(AlgebraVectorial v) {
        return this.x * v.x + this.y * v.y + this.z * v.z;
    }
    public AlgebraVectorial productoCruz(AlgebraVectorial v) {
        double cx = this.y * v.z - this.z * v.y;
        double cy = this.z * v.x - this.x * v.z;
        double cz = this.x * v.y - this.y * v.x;
        return new AlgebraVectorial(cx, cy, cz);
    }

    public double norma() {
        return Math.sqrt(x * x + y * y + z * z);
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getZ() {
        return z;
    }

    public void setZ(double z) {
        this.z = z;
    }


}