package ejercicio2;
public class Test {
    public static void main(String[] args) {
        Vector3D a = new Vector3D(1, 2, 3);
        Vector3D b = new Vector3D(4, 5, 6);

        System.out.println("Vector a: " + a);
        System.out.println("Vector b: " + b);

        System.out.println("Suma: a + b = " + a.add(b));
        System.out.println("Escalar * a (2.0): " + a.add(2.0));
        System.out.println("Longitud de a: " + a.add());
        System.out.println("Normalizado de a: " + a.scale());
        System.out.println("Producto escalar a . b: " + a.dot(b));
        System.out.println("Producto vectorial a x b: " + a.cross(b));
        System.out.println("Proyeccion de a sobre b: " + a.projectOnto(b));
        System.out.print("a es perpendicular u ortogonal a b?: ");
        if(a.isOrthogonalTo(b)){
            System.out.println("Si");
        }
        else{
            System.out.println("no");
        }
    }
}

