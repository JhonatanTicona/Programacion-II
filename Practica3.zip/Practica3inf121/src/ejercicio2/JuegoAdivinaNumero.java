package ejercicio2;
import java.util.Scanner;
import java.util.Random;
public class JuegoAdivinaNumero extends Juego{
	
	protected int numeroAAdivinar;
    protected Random random = new Random();
    protected Scanner sc = new Scanner(System.in);

    public JuegoAdivinaNumero(int numeroDeVidas) {
        super(numeroDeVidas);
    }
    public boolean validaNumero(int num) {
        return (num >= 0 && num <= 10);
    }
    public void validaNAAdivinar(int intento) {
    	
    }

    public void juega() {
        reiniciaPartida(numeroDeVidas);
        numeroAAdivinar = random.nextInt(11); 

        System.out.println("\n Este es el juego de adivinar el numero!");
        System.out.println("Debes adivinar un numero entre 0 y 10. Tienes " + numeroDeVidas + " vidas.");
		validaNAAdivinar(numeroAAdivinar);
		
        while (true) {
            System.out.print("Ingresa tu numero: ");
            int intento = sc.nextInt();

            if (!validaNumero(intento)) {
                System.out.println("Numero inválido. Debe estar entre 0 y 10.");
                continue;
            }
            
            if (intento == numeroAAdivinar) {
                System.out.println("¡Acertaste!");
                actualizaRecord(numeroDeVidas);
                break;
            } else {
                if (quitaVida()) {
                    if (intento < numeroAAdivinar) {
                        System.out.println("El numero es mayor. Te quedan " + numeroDeVidas + " vidas.");
                    } else {
                        System.out.println("El numero es menor. Te quedan " + numeroDeVidas + " vidas.");
                    }
                } else {
                    System.out.println("X Te quedaste sin vidas. El numero era: " + numeroAAdivinar);
                    break;
                }
            }
        }
    }

    
}