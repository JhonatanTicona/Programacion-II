package ejercicio2;
class JuegoAdivinaImpar extends JuegoAdivinaNumero {
    public JuegoAdivinaImpar(int numeroDeVidas) {
        super(numeroDeVidas);
    }
    @Override
    public void validaNAAdivinar(int n) {
    	while(true) {
    		if(n%2!=0) {
    			numeroAAdivinar=n;
    			break;
    		}
    		n = random.nextInt(11);
    	}
    }
    @Override
    public boolean validaNumero(int num) {
    	
        if (num < 0 || num > 10) {
            return false;
        }
        if (num % 2 != 0) {
            return true;
        } else {
            System.out.println("Error: solo se permiten numeros impares.");
            return false;
        }
    }
}
