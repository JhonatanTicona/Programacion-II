package ejercicio1;

import java.util.Random;
import java.util.Scanner;

class JuegoAdivinaNumero extends Juego {
 private int numeroAAdivinar;
 private Random random = new Random();
 private Scanner sc = new Scanner(System.in);

 public JuegoAdivinaNumero(int numeroDeVidas) {
     super(numeroDeVidas);
 }

 public void juega() {
     reiniciaPartida(numeroDeVidas);
     numeroAAdivinar = random.nextInt(11);
     System.out.println(" Bienvenido al juego de adivinar el número!");
     System.out.println("Tienes " + numeroDeVidas + " vidas.");
     System.out.println("Adivina un número entre 0 y 10:");
     while (true) {
         int intento = sc.nextInt();
         if (intento == numeroAAdivinar) {
             System.out.println("¡Acertaste!");
             actualizaRecord(numeroDeVidas);
             break;
         } else {
             if (quitaVida()) {
                 if (intento < numeroAAdivinar) {
                     System.out.println("El numero es mayor. Te quedan " + numeroDeVidas + " vidas.");
                 } else {
                     System.out.println("El numero es menor. Te quedan " + numeroDeVidas + " vidas.");
                 }
                 System.out.print("Intenta de nuevo: ");
             } else {
                 System.out.println("X Te quedaste sin vidas. El numero era: " + numeroAAdivinar);
                 break;
             }
         }
     }
 }
}
