package ejercicio1;

public class Aplicacion {
    public static void main(String[] args) {
        JuegoAdivinaNumero juego = new JuegoAdivinaNumero(5);
        juego.juega();
    }
}