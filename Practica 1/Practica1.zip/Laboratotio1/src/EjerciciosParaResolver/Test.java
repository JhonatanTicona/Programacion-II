package EjerciciosParaResolver;
import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		double a,b,c,d,e,f;
		System.out.println("Solucion de una ecuacion Lineal");
		System.out.println("Ingresar a:");
		a=sc.nextDouble();
		System.out.println("Ingresar b:");
		b=sc.nextDouble();
		System.out.println("Ingresar c:");
		c=sc.nextDouble();
		System.out.println("Ingresar d:");
		d=sc.nextDouble();
		System.out.println("Ingresar e:");
		e=sc.nextDouble();
		System.out.println("Ingresar f:");
		f=sc.nextDouble();
		EcuacionLineal ecuacion=new EcuacionLineal(a,b,c,d,e,f);
		if(ecuacion.TieneSolucion()) {
			System.out.println("X: "+ecuacion.getX());

			System.out.println("Y: "+ecuacion.getY());
			
		}
		else {
			System.out.println("La ecuacion no tiene solucion");
		}
	}
	
}
