package EjerciciosParaResolver;

public class EcuacionLineal {
	private double a,b,c,d,e,f;
	
	public EcuacionLineal(double a,double b,double c,double d,double e,double f) {
		this.a=a;
		this.b=b;
		this.c=c;
		this.d=d;
		this.e=e;
		this.f=f;
	}
	public boolean TieneSolucion() {
		double r=(a*d)-(b*c);
		if(r!=0) {
			return true;
		}
		return false;
	}
	public double getX() {
		double x=((e*d)-(b*f))/((a*d)-(b*c));
		return x;
	}
	public double getY() {
		double y=((a*f)-(e*c))/((a*d)-(b*c));
		return y;
	}

}
