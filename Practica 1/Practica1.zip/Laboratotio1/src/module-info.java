/**
 * 
 */
/**
 * 
 */
module Laboratotio1 {
}