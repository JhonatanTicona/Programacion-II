package Ejercicio3;

public class Estadistica {
	   private double v[] = new double[100];
	    private int nrov = 0;

	    public void agregarV(double x) {
	        v[nrov] = x; 
	        nrov++;
	    }

	    public double promedio() {
	        double suma = 0;
	        for (int i = 0; i < nrov; i++) {
	            suma += v[i];
	        }
	        return suma / nrov;
	    }

	    public double desviacion() {
	        double p = promedio();
	        double suma = 0;
	        for (int i = 0; i < nrov; i++) {
	            suma += Math.pow(v[i] - p, 2);
	        }
	        return Math.sqrt(suma / (nrov - 1));
	    }
}
