package Ejercicio3;
import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n;
		double x;
		Estadistica e=new Estadistica();
		System.out.println("Calcular el promedio y la desviacion estandar:");
		System.out.println("Ingresar n numeros:");
		n=sc.nextInt();
		for(int i=1;i<=n;i++) {
			System.out.println("Ingresar x:");
			x=sc.nextDouble();
			e.agregarV(x);
		}
		System.out.println("El promedio es "+ String.format("%.2f",e.promedio()));
		System.out.println("La desviacion estandar es "+ String.format("%.5f", e.desviacion()));	
	}

}
