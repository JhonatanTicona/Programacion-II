package Ejercicio2;

public class EcuacionLineal {
	private double a,b,c;
	
	public EcuacionLineal(double a,double b,double c) {
		this.a=a;
		this.b=b;
		this.c=c;
	}
	public double getDiscriminante() {
		double d=(Math.pow(b, 2)-(4*a*c));
		return d;
	}
	public double getRaiz1() {
		double r1=(-b+Math.sqrt(Math.pow(b,2)-4*a*c))/(2*a);
		return r1;
	}
	public double getRaiz2() {
		double r2=(-b-Math.sqrt(Math.pow(b,2)-4*a*c))/(2*a);
		return r2;
	}

}
