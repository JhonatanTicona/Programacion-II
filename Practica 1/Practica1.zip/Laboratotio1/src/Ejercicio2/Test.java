package Ejercicio2;
import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		double a,b,c;
		System.out.println("Solucion de una ecuacion Cuadratica");
		System.out.println("Ingresar a:");
		a=sc.nextDouble();
		System.out.println("Ingresar b:");
		b=sc.nextDouble();
		System.out.println("Ingresar c:");
		c=sc.nextDouble();
		EcuacionLineal e=new EcuacionLineal(a,b,c);
		if(e.getDiscriminante()>0) {
			System.out.println("La Ecuacion tiene dos raices "+e.getRaiz1()+" "+e.getRaiz2());
		}
		else {
			if(e.getDiscriminante()==0) {
				System.out.println("La Ecuacion tiene una raiz "+e.getRaiz1());
			}
			else {
				System.out.println("La ecuacion no tiene raices reales");
			}
		}
	}

}
